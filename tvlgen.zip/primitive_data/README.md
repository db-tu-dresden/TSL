# TVLPrimitiveData
Template Vector Library Primitive Data

[![Integrity Check (Primitive Data)](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/generator_integrity_check_pipeline.yml/badge.svg)](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/generator_integrity_check_pipeline.yml)
[![Building Library](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/build_library_pipeline.yml/badge.svg)](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/build_library_pipeline.yml)
[![Testing Library](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/test_library_pipeline.yml/badge.svg)](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/test_library_pipeline.yml)
[![Published](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/update_tvl_gen.yml/badge.svg)](https://github.com/db-tu-dresden/TVLPrimitiveData/actions/workflows/update_tvl_gen.yml)