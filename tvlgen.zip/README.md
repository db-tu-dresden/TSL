# TVLGen
Template Vector Library Generator

[![Integrity Check (Primitive Data)](https://github.com/db-tu-dresden/TVLGen/actions/workflows/generator_integrity_check_pipeline.yml/badge.svg)](https://github.com/db-tu-dresden/TVLGen/actions/workflows/generator_integrity_check_pipeline.yml)
[![Published](https://github.com/db-tu-dresden/TVLGen/actions/workflows/update_tvl.yml/badge.svg)](https://github.com/db-tu-dresden/TVLGen/actions/workflows/update_tvl.yml)